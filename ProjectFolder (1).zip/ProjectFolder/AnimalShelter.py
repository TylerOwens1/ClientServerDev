from pymongo import MongoClient

from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username='aacuser', password='password' ):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        #username = 'aacuser'
        #password = 'password'
        self.client = MongoClient('mongodb://%s:%s@localhost:56677/AAC' % (username, password))    
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary returns true if data is inserted          
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD. aka read
    def find(self, serch_criteria=None):
        if serch_criteria is not None:
            return self.database.animals.find( serch_criteria, {"_id":False} )
        else:
            raise Exception("Parameter is empty")
            
#finds wather rescue dogs based on chart given
    def find_water_rescue(self):
        return self.database.animals.find({ "breed":{ "$in" : [ "Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland Mix"] }, "sex_upon_outcome": "Intact Female", "age_upon_outcome_in_weeks":{ "$gt": 25 }, "age_upon_outcome_in_weeks":{ "$lt": 157 } },{"_id":False})
        
        
        
#finds mountain rescue dogs based on chart given
    def find_mountain_rescue(self):
        return self.database.animals.find({ "breed":{ "$in" : [ "German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"] }, "sex_upon_outcome": "Intact Male", "age_upon_outcome_in_weeks":{ "$gt": 25 }, "age_upon_outcome_in_weeks":{ "$lt": 157 } },{"_id":False})   
    
#finds mountain Disaster dogs based on chart given
    def find_disaster_rescue(self):
        return self.database.animals.find({ "breed":{ "$in" : [ "German Shepherd", "Doberman Pinscher", "Golden Retriever", "Golden Retriever", "Rottweiler"] }, "sex_upon_outcome": "Intact Male", "age_upon_outcome_in_weeks":{ "$gt": 19 }, "age_upon_outcome_in_weeks":{ "$lt": 201 } },{"_id":False})   
    
    
            
# Create method to implement the R in CRUD. aka read one
    def find_one(self):
        if serch_criteria is not None:
            return self.database.animals.find_one()
        else:
            raise Exception("Parameter is empty")
            
# Create method to implement the U in CRUD. aka Update
    def update(self, serch_criteria=None, new_values=None):
        if serch_criteria is not None and new_values is not None:
            return self.database.animals.update(serch_criteria, new_values)
        else:
            raise Exception("Parameter is empty")
            

# Create method to implement the D in CRUD. aka Delete delets only one
    def delete(self, serch_criteria=None):
        if serch_criteria is not None:
            return self.database.animals.delete_one(serch_criteria)
        else:
            raise Exception("Parameter is empty")